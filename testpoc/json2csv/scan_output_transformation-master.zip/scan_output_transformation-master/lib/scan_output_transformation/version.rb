module ScanOutputTransformation
  VERSION = "1.0"
end

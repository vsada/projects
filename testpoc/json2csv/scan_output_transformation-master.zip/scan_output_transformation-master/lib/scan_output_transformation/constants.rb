module ScanOutputTransformation

  module Constants

    ROOT_REMOTE = "/apps/healthd/scan"
    RESULTS_REMOTE = "#{ROOT_REMOTE}/results"

    SSH_HOST    = "158.87.123.157"
    SSH_USER    = "dauto"
    SSH_PASS    = "dqm50vnc"

  end

end
